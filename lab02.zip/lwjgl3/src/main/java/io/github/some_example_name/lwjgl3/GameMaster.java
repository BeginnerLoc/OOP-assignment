package io.github.some_example_name.lwjgl3;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class GameMaster extends ApplicationAdapter {

    private SpriteBatch batch;
    private TextureObject bucket;
    private TextureObject[] droplets;

    @Override
    public void create() {
        batch = new SpriteBatch();
        droplets = new TextureObject[10];
        for (int i = 0; i < droplets.length; i++) {
            int randomSpeed = 2 + (int) (Math.random() * 5);
            TextureObject drop = new TextureObject("droplet.png", 50 * i, 125 * i, randomSpeed);
            droplets[i] = drop;
        }
        bucket = new TextureObject("bucket.png", 200, 0, 0);
    }

    @Override
    public void render() {
        ScreenUtils.clear(0, 0, 0.2f, 1);
        batch.begin();
        for (TextureObject drop : droplets) {
            drop.setY(drop.getY() - drop.getSpeed());
            if (drop.getY() <= 0) {
                drop.setY(400);
                drop.setSpeed(Math.min(drop.getSpeed() + 1, 10));
            }
            batch.draw(drop.getTex(), drop.getX(), drop.getY(), drop.getTex().getWidth(), drop.getTex().getHeight());
        }
        batch.draw(bucket.getTex(), bucket.getX(), bucket.getY(), bucket.getTex().getWidth(), bucket.getTex().getHeight());
        batch.end();
        if (Gdx.input.isKeyPressed(Keys.LEFT)) 
            bucket.setX(bucket.getX() - 200 * Gdx.graphics.getDeltaTime());
        if (Gdx.input.isKeyPressed(Keys.RIGHT)) 
            bucket.setX(bucket.getX() + 200 * Gdx.graphics.getDeltaTime());
    }

    @Override
    public void dispose() {
        batch.dispose();
    }
}
