package io.github.some_example_name.lwjgl3;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;

public class TextureObject {
	
	private Texture tex;
	private float x;
	private float y;
	private float speed;
	
	public TextureObject() {
		
	}
	
	public TextureObject(String texImg, float x, float y, float speed) {
		super();
		this.tex = new Texture(Gdx.files.internal(texImg));
		this.x = x;
		this.y = y;
		this.speed = speed;
	}


	
	public Texture getTex() {
		return tex;
	}

	public void setTex(Texture tex) {
		this.tex = tex;
	}

	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public float getSpeed() {
		return speed;
	}

	public void setSpeed(float speed) {
		this.speed = speed;
	}
	
	
	
}
